/**
 * Lucid Night — Gemini AI analytics (Vercel serverless)
 * POST /api/analyze  body: { entries: [{ date, title, text }] }
 */
import { GoogleGenAI } from '@google/genai';

const MODEL = process.env.GEMINI_MODEL || 'gemini-3.6-flash';
const MAX_ENTRIES = 30;
const MAX_TITLE = 200;
const MAX_TEXT = 3000;

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch (e) {
        reject(new Error('Invalid JSON body'));
      }
    });
    req.on('error', reject);
  });
}

function sanitizeEntries(entries) {
  if (!Array.isArray(entries)) return null;
  return entries
    .slice(-MAX_ENTRIES)
    .map((entry) => ({
      date: entry && entry.date ? String(entry.date).slice(0, 40) : '',
      title: String((entry && entry.title) || '').slice(0, MAX_TITLE),
      text: String((entry && (entry.text || entry.transcript)) || '').slice(0, MAX_TEXT),
    }))
    .filter((e) => e.text.trim().length > 0);
}

function stripFences(text) {
  let t = String(text || '').trim();
  return t.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
}

function safeParseAnalytics(text) {
  const cleaned = stripFences(text);
  let parsed;
  try {
    parsed = JSON.parse(cleaned);
  } catch (e) {
    const start = cleaned.indexOf('{');
    const end = cleaned.lastIndexOf('}');
    if (start >= 0 && end > start) parsed = JSON.parse(cleaned.slice(start, end + 1));
    else throw new Error('Malformed AI output');
  }
  return {
    summary: String(parsed.summary || '').slice(0, 2000),
    themes: Array.isArray(parsed.themes) ? parsed.themes.slice(0, 12) : [],
    emotions: Array.isArray(parsed.emotions) ? parsed.emotions.slice(0, 12) : [],
    recurringSymbols: Array.isArray(parsed.recurringSymbols)
      ? parsed.recurringSymbols.slice(0, 12)
      : [],
    reflectionQuestions: Array.isArray(parsed.reflectionQuestions)
      ? parsed.reflectionQuestions.slice(0, 8).map((q) => String(q).slice(0, 300))
      : [],
    disclaimer:
      String(parsed.disclaimer || '').trim() ||
      'This is reflective pattern analysis, not medical or psychological diagnosis.',
  };
}

function buildPrompt(limitedEntries) {
  return `Analyze the following dream-journal entries.
Return ONLY valid JSON using this structure:
{
  "summary": "short overall summary",
  "themes": [{ "name": "theme name", "count": 0, "description": "brief explanation" }],
  "emotions": [{ "name": "emotion", "strength": 0 }],
  "recurringSymbols": [{ "symbol": "symbol", "count": 0, "possibleMeaning": "careful, non-definitive interpretation" }],
  "reflectionQuestions": ["question 1", "question 2"],
  "disclaimer": "This is reflective pattern analysis, not medical or psychological diagnosis."
}
Rules:
- Do not diagnose mental-health conditions.
- Do not claim universal symbol meanings.
- Say "may suggest" rather than certain claims.
- Do not invent information not in the entries.
- Keep concise. Treat entries as private.
Entries:
${JSON.stringify(limitedEntries)}`;
}

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.end();
    return;
  }
  if (req.method !== 'POST') return json(res, 405, { error: 'Method not allowed' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return json(res, 500, { error: 'Server is not configured. Missing GEMINI_API_KEY.' });

  let body;
  try {
    body = typeof req.body === 'object' && req.body !== null ? req.body : await readBody(req);
  } catch (e) {
    return json(res, 400, { error: 'Invalid JSON body' });
  }

  const limitedEntries = sanitizeEntries(body.entries);
  if (!limitedEntries) return json(res, 400, { error: 'entries must be an array' });
  if (!limitedEntries.length) return json(res, 400, { error: 'No journal text to analyze' });

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: MODEL,
      contents: buildPrompt(limitedEntries),
      config: { temperature: 0.4, maxOutputTokens: 2048, responseMimeType: 'application/json' },
    });
    const text = response && response.text ? response.text : '';
    if (!text) return json(res, 502, { error: 'Empty response from AI provider' });
    let analytics;
    try {
      analytics = safeParseAnalytics(text);
    } catch (e) {
      return json(res, 502, { error: 'Could not parse AI analytics output' });
    }
    return json(res, 200, analytics);
  } catch (error) {
    const msg = String((error && error.message) || error || '');
    console.error('[analyze]', msg.slice(0, 200));
    if (/quota|rate|429/i.test(msg)) {
      return json(res, 429, { error: 'AI quota or rate limit reached. Try again later.' });
    }
    return json(res, 500, { error: 'Analytics request failed' });
  }
}
