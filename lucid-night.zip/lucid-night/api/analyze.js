/**
 * Lucid Night — analytics (Vercel serverless)
 * POST /api/analyze
 */
import { GoogleGenAI } from '@google/genai';

const MODEL_CHAIN = (
  process.env.GEMINI_MODEL
    ? [process.env.GEMINI_MODEL]
    : ['gemini-3.5-flash-lite', 'gemini-3.5-flash', 'gemini-3.1-flash-lite', 'gemini-3.6-flash']
).filter(Boolean);

const MAX_ENTRIES = 30;
const MAX_TITLE = 200;
const MAX_TEXT = 3000;

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.end(JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch (e) {
        reject(new Error('Invalid JSON body'));
      }
    });
    req.on('error', reject);
  });
}

function sanitizeEntries(entries) {
  if (!Array.isArray(entries)) return null;
  return entries
    .slice(-MAX_ENTRIES)
    .map((entry) => ({
      date: entry && entry.date ? String(entry.date).slice(0, 40) : '',
      title: String((entry && entry.title) || '').slice(0, MAX_TITLE),
      text: String((entry && (entry.text || entry.transcript)) || '').slice(0, MAX_TEXT),
    }))
    .filter((e) => e.text.trim().length > 0);
}

function stripFences(text) {
  let t = String(text || '').trim();
  return t.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
}

function extractJsonObject(text) {
  const cleaned = stripFences(text);
  try {
    return JSON.parse(cleaned);
  } catch {}
  const s = cleaned.indexOf('{');
  const e = cleaned.lastIndexOf('}');
  if (s >= 0 && e > s) {
    const slice = cleaned.slice(s, e + 1);
    try {
      return JSON.parse(slice);
    } catch {}
    try {
      return JSON.parse(slice.replace(/,\s*([}\]])/g, '$1'));
    } catch {}
  }
  throw new Error('Malformed AI output');
}

function namedCounts(arr, nameKey, max) {
  if (!Array.isArray(arr)) return [];
  const out = [];
  const seen = new Set();
  for (const item of arr) {
    if (out.length >= max) break;
    let name = '';
    let count = 1;
    if (typeof item === 'string') name = item;
    else if (item && typeof item === 'object') {
      name = String(item[nameKey] || item.name || item.label || '').trim();
      count = Math.max(1, Number(item.count != null ? item.count : 1) || 1);
    }
    name = name.slice(0, 80);
    if (!name) continue;
    const k = name.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push({ name, count });
  }
  return out;
}

function normalizeAnalytics(parsed) {
  const emotionsRaw = Array.isArray(parsed.emotions) ? parsed.emotions : [];
  const emotions = [];
  const seenE = new Set();
  for (const e of emotionsRaw) {
    if (emotions.length >= 12) break;
    let name = '';
    let strength = 5;
    let count = 1;
    if (typeof e === 'string') name = e;
    else if (e && typeof e === 'object') {
      name = String(e.emotion || e.name || '').trim();
      strength = Math.min(10, Math.max(0, Number(e.strength != null ? e.strength : 5) || 5));
      count = Math.max(1, Number(e.count != null ? e.count : 1) || 1);
    }
    name = name.slice(0, 60);
    if (!name) continue;
    const k = name.toLowerCase();
    if (seenE.has(k)) continue;
    seenE.add(k);
    emotions.push({ name, count, strength });
  }
  return {
    summary: String(parsed.summary || '').slice(0, 2000),
    dreamOverview: String(parsed.dreamOverview || parsed.overview || '').slice(0, 1200),
    themes: Array.isArray(parsed.themes) ? parsed.themes.slice(0, 12).map((t) => String(t).slice(0, 80)).filter(Boolean) : [],
    people: namedCounts(parsed.people, 'name', 12),
    places: namedCounts(parsed.places, 'name', 12),
    animals: namedCounts(parsed.animals, 'name', 12),
    actions: namedCounts(parsed.actions, 'name', 12),
    presences: namedCounts(parsed.presences, 'name', 12),
    emotions,
    recurringSymbols: Array.isArray(parsed.recurringSymbols)
      ? parsed.recurringSymbols.slice(0, 12).map((s) => ({
          symbol: String((s && s.symbol) || s || '').slice(0, 80),
          count: Math.max(0, Number((s && s.count) != null ? s.count : 1) || 1),
          possibleMeaning: String((s && s.possibleMeaning) || '').slice(0, 200),
        })).filter((s) => s.symbol)
      : [],
    reflectionQuestions: Array.isArray(parsed.reflectionQuestions)
      ? parsed.reflectionQuestions.slice(0, 8).map((q) => String(q).slice(0, 300)).filter(Boolean)
      : [],
    disclaimer:
      String(parsed.disclaimer || '').trim() ||
      'This is reflective pattern analysis, not medical or psychological diagnosis.',
  };
}

function isRetryable(msg) {
  return /503|UNAVAILABLE|high demand|overloaded|RESOURCE_EXHAUSTED|rate|429|quota|temporarily/i.test(String(msg || ''));
}

function buildPrompt(limitedEntries, extra = {}) {
  const mostRecent = extra.mostRecent || (limitedEntries[0] || null);
  const dreamTypes = extra.dreamTypes || {};
  const hints = extra.hints || {};
  return `You analyse private dream journal entries. Focus especially on the MOST RECENT dream while still noticing patterns across the set. You are the ONLY source of people, places, animals, actions, emotions, and presences lists that will appear in the analytics UI.

Return ONLY one JSON object. No markdown. No code fences.

Shape:
{
  "summary": "2-4 sentences on concrete patterns, prioritising the most recent dream",
  "dreamOverview": "2-4 short sentences: a generalized, gentle interpretation connecting common dream themes in these entries to possible real-life emotions or situations. Use words like may, could, can sometimes, might. Never present interpretations as facts or diagnoses.",
  "themes": ["theme1", "theme2"],
  "people": [{ "name": "Proper name or clear role only", "count": 1 }],
  "places": [{ "name": "Specific place", "count": 1 }],
  "animals": [{ "name": "Animal", "count": 1 }],
  "actions": [{ "name": "Meaningful action", "count": 1 }],
  "presences": [{ "name": "Ghost / shadow / presence label", "count": 1 }],
  "emotions": [{ "emotion": "feeling", "strength": 7, "count": 1 }],
  "recurringSymbols": [{ "symbol": "symbol", "count": 2, "possibleMeaning": "may suggest ..." }],
  "reflectionQuestions": ["q1", "q2", "q3"],
  "disclaimer": "This is reflective pattern analysis, not medical or psychological diagnosis."
}

Hard rules for people / places / animals / actions / emotions / presences:
- ONLY real proper names, clear roles (mom, teacher), real places, real animals, meaningful verbs, clear feelings, and presence-like beings from the text.
- presences = ghosts, spirits, shadows, dark figures, weird unseen feelings of being watched, entities, phantoms, demons, angels, aliens, creatures felt as a presence (not ordinary animals or people already listed).
- NEVER output grammar fragments: "was there", "i was", "there", "someone", "something", "it", "they".
- NEVER invent names or details not present in the entries.
- count = how many entries that item appears in (minimum 1).
- If none, use [].
- Give extra weight to the most recent dream when ranking and counting.

dreamOverview rules:
- Short and easy to read (2-4 sentences).
- Connect themes that appear (e.g. water, chasing, falling, flying, monsters, being trapped) to possible waking-life feelings using tentative language only.
- Examples of tone: nightmares may relate to stress; being chased might relate to pressure; falling can sometimes reflect uncertainty; water may relate to emotions; flying might connect with freedom or wanting more control; death in dreams is usually symbolic of change or endings, not literal.
- Never diagnose, predict harm, or claim certainty.

Other rules:
- themes: 3-6 short phrases from the dreams
- emotions: 2-6 items, strength 1-10
- reflectionQuestions: exactly 3, different, tied to the dreams (especially the latest)
- No medical diagnosis

Dream type counts across the journal: ${JSON.stringify(dreamTypes)}
Most recent dream: ${JSON.stringify(mostRecent)}
Optional local hints (may be incomplete — verify against the text): ${JSON.stringify(hints)}

All entries (most recent first):
${JSON.stringify(limitedEntries)}`;
}

async function generateJSON(apiKey, prompt) {
  const ai = new GoogleGenAI({ apiKey });
  let lastErr = null;
  for (const model of MODEL_CHAIN) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: { temperature: 0.4, maxOutputTokens: 2048, responseMimeType: 'application/json' },
      });
      const text = response && response.text ? String(response.text) : '';
      if (!text.trim()) {
        lastErr = new Error('Empty response');
        continue;
      }
      return extractJsonObject(text);
    } catch (err) {
      lastErr = err;
      const msg = String(err?.message || err || '');
      if (/API_KEY|401|403/i.test(msg)) break;
    }
  }
  throw lastErr || new Error('All models failed');
}

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') return json(res, 204, {});
  if (req.method !== 'POST') return json(res, 405, { error: 'Method not allowed' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return json(res, 500, { error: 'Server is not configured. Missing GEMINI_API_KEY.' });

  let body;
  try {
    body = typeof req.body === 'object' && req.body !== null ? req.body : await readBody(req);
  } catch (e) {
    return json(res, 400, { error: 'Invalid JSON body' });
  }

  const limitedEntries = sanitizeEntries(body.entries);
  if (!limitedEntries) return json(res, 400, { error: 'entries must be an array' });
  if (!limitedEntries.length) return json(res, 400, { error: 'No journal text to analyze' });

  const extra = {
    mostRecent: body.mostRecent || limitedEntries[0] || null,
    dreamTypes: body.dreamTypes || {},
    hints: body.hints || {},
  };

  try {
    const parsed = await generateJSON(apiKey, buildPrompt(limitedEntries, extra));
    return json(res, 200, normalizeAnalytics(parsed));
  } catch (error) {
    const msg = String((error && error.message) || error || '');
    console.error('[analyze]', msg.slice(0, 200));
    if (isRetryable(msg)) return json(res, 503, { error: 'The model is busy right now. Wait a few seconds and try again.' });
    return json(res, 500, { error: 'Analytics request failed. Try again in a moment.' });
  }
}
