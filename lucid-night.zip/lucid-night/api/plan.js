/**
 * Lucid Night — AI lucid plan (Vercel serverless)
 * POST /api/plan
 */
import { GoogleGenAI } from '@google/genai';

const MODEL_CHAIN = (
  process.env.GEMINI_MODEL
    ? [process.env.GEMINI_MODEL]
    : ['gemini-3.5-flash-lite', 'gemini-3.5-flash', 'gemini-3.1-flash-lite', 'gemini-3.6-flash']
).filter(Boolean);

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.end(JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

function stripFences(text) {
  let t = String(text || '').trim();
  return t.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
}

function extractJsonObject(text) {
  const cleaned = stripFences(text);
  try { return JSON.parse(cleaned); } catch {}
  const s = cleaned.indexOf('{');
  const e = cleaned.lastIndexOf('}');
  if (s >= 0 && e > s) {
    try { return JSON.parse(cleaned.slice(s, e + 1)); } catch {}
  }
  throw new Error('Malformed AI output');
}

function isRetryable(msg) {
  return /503|UNAVAILABLE|high demand|overloaded|RESOURCE_EXHAUSTED|rate|429|quota|temporarily/i.test(String(msg || ''));
}

async function generateJSON(apiKey, prompt) {
  const ai = new GoogleGenAI({ apiKey });
  let lastErr = null;
  for (const model of MODEL_CHAIN) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: { temperature: 0.7, maxOutputTokens: 2500, responseMimeType: 'application/json' },
      });
      const text = response && response.text ? String(response.text) : '';
      if (!text.trim()) { lastErr = new Error('Empty response'); continue; }
      return extractJsonObject(text);
    } catch (err) {
      lastErr = err;
      const msg = String(err?.message || err || '');
      if (/API_KEY|401|403/i.test(msg)) break;
    }
  }
  throw lastErr || new Error('All models failed');
}

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') return json(res, 204, {});
  if (req.method !== 'POST') return json(res, 405, { error: 'Method not allowed' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return json(res, 500, { error: 'Missing GEMINI_API_KEY' });

  let body;
  try {
    body = typeof req.body === 'object' && req.body ? req.body : await readBody(req);
  } catch {
    return json(res, 400, { error: 'Invalid JSON' });
  }

  const entries = Array.isArray(body.entries) ? body.entries.slice(-20) : [];
  const existing = body.existingPlan && typeof body.existingPlan === 'object' ? body.existingPlan : null;
  const instruction = String(body.instruction || '').slice(0, 800);

  const prompt = `You create a fun, practical, age-safe personal lucid dreaming PLAN from a private dream journal.

Return ONLY one JSON object. No markdown.

Shape:
{
  "title": "short punchy plan name",
  "tagline": "one exciting sentence",
  "level": "Spark | Explorer | Navigator | Dream Rider",
  "xpTarget": 100,
  "focus": "main skill this week",
  "mission": "2-3 sentences: why THIS journal points to this plan. Mention real dream signs from the entries.",
  "dreamSigns": ["sign from the journal", "another"],
  "goals": [
    { "id": "g1", "title": "short goal", "why": "why it helps lucidity", "xp": 15 }
  ],
  "days": [
    { "id": "d1", "name": "Mon", "title": "short day title", "tasks": ["tiny action 1", "tiny action 2"], "tip": "one line tip" }
  ],
  "quests": [
    { "id": "q1", "name": "quest name", "desc": "what to try in a dream or by day", "stars": 2 }
  ],
  "realityCue": "one custom reality-check tied to their dream signs",
  "bedtimeScript": "4-6 short lines they can whisper as they fall asleep. Gentle, no fear.",
  "coachNote": "one encouraging closer"
}

Rules:
- Family-friendly. No horror, no substances, no sleep deprivation, no mid-night alarm bootcamps, no medical claims.
- Techniques allowed: dream journal, reality checks, gentle MILD intention, spotting personal dream signs, consistent sleep, morning recall, calm visualization.
- Use the actual people/places/themes/animals from the journal as dream signs when present.
- Exactly 5 goals, 7 days (Mon-Sun), 3 quests.
- Keep language energetic, game-like, clear.
- If an existing plan + instruction is provided, REWRITE the plan to apply that instruction while keeping useful parts.
${instruction ? 'Rewrite instruction from the dreamer: ' + instruction : 'Create a fresh plan.'}
Existing plan (may be null): ${JSON.stringify(existing).slice(0, 3500)}
Journal entries (most recent first): ${JSON.stringify(entries).slice(0, 9000)}`;

  try {
    const parsed = await generateJSON(apiKey, prompt);
    return json(res, 200, parsed);
  } catch (err) {
    const msg = String(err?.message || err || '');
    console.error('[plan]', msg.slice(0, 200));
    if (isRetryable(msg)) return json(res, 503, { error: 'The model is busy right now. Wait a few seconds and try again.' });
    return json(res, 500, { error: 'Plan request failed. Try again in a moment.' });
  }
}
