/**
 * Lucid Night — Lucid Expert chat
 * POST /api/chat
 */
import { GoogleGenAI } from '@google/genai';

const MODEL_CHAIN = (
  process.env.GEMINI_MODEL
    ? [process.env.GEMINI_MODEL]
    : ['gemini-3.5-flash-lite', 'gemini-3.5-flash', 'gemini-3.1-flash-lite', 'gemini-3.6-flash']
).filter(Boolean);

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.end(JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

function stripFences(text) {
  let t = String(text || '').trim();
  return t.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
}

function extractJsonObject(text) {
  const cleaned = stripFences(text);
  try { return JSON.parse(cleaned); } catch {}
  const s = cleaned.indexOf('{');
  const e = cleaned.lastIndexOf('}');
  if (s >= 0 && e > s) {
    try { return JSON.parse(cleaned.slice(s, e + 1)); } catch {}
  }
  throw new Error('Malformed AI output');
}

function isRetryable(msg) {
  return /503|UNAVAILABLE|high demand|overloaded|RESOURCE_EXHAUSTED|rate|429|quota|temporarily/i.test(String(msg || ''));
}

async function generateJSON(apiKey, prompt) {
  const ai = new GoogleGenAI({ apiKey });
  let lastErr = null;
  for (const model of MODEL_CHAIN) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: { temperature: 0.75, maxOutputTokens: 1200, responseMimeType: 'application/json' },
      });
      const text = response && response.text ? String(response.text) : '';
      if (!text.trim()) { lastErr = new Error('Empty response'); continue; }
      return extractJsonObject(text);
    } catch (err) {
      lastErr = err;
      const msg = String(err?.message || err || '');
      if (/API_KEY|401|403/i.test(msg)) break;
    }
  }
  throw lastErr || new Error('All models failed');
}

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') return json(res, 204, {});
  if (req.method !== 'POST') return json(res, 405, { error: 'Method not allowed' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return json(res, 500, { error: 'Missing GEMINI_API_KEY' });

  let body;
  try {
    body = typeof req.body === 'object' && req.body ? req.body : await readBody(req);
  } catch {
    return json(res, 400, { error: 'Invalid JSON' });
  }

  const message = String(body.message || '').slice(0, 1200);
  if (!message.trim()) return json(res, 400, { error: 'Empty message' });

  const history = Array.isArray(body.history) ? body.history.slice(-12) : [];
  const entries = Array.isArray(body.entries) ? body.entries.slice(-24) : [];

  const prompt = `You are Lucid Genius, a helpful dream chat. Sound like a normal person — clear, friendly, not cutesy.
No "heyyy", "oooh", "dream muscle", or hype-coach talk.

Rules:
- Stay on dreams, sleep, and lucid dreaming.
- You can ONLY use attached dreams below. If the list is empty, you do not know their journal. Tell them to attach a dream with the clip button if they want you to read one.
- Never invent journal details that are not in the attached list.
- Greetings get a normal hello plus a simple dream invite. Not just "hey".
- Short messages can get short replies. Real questions get a useful answer.
- Break up text. Use bullets when a list helps.
- Family-friendly. No medical diagnosis.

Return ONLY JSON: {"reply":"text"}

Attached dreams (only these): ${JSON.stringify(entries).slice(0, 12000)}
Chat history: ${JSON.stringify(history).slice(0, 4000)}
User message: ${message}`;

  try {
    const parsed = await generateJSON(apiKey, prompt);
    const reply = String(parsed.reply || '').trim().slice(0, 1800) || 'Ask me anything about a dream in your journal.';
    return json(res, 200, { reply });
  } catch (err) {
    const msg = String(err?.message || err || '');
    console.error('[chat]', msg.slice(0, 200));
    if (isRetryable(msg)) return json(res, 503, { error: 'The model is busy right now. Wait a few seconds and try again.' });
    return json(res, 500, { error: 'Chat request failed. Try again in a moment.' });
  }
}
