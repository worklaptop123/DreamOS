/**
 * Lucid Night — per-dream meaning (Vercel serverless)
 * POST /api/meaning
 */
import { GoogleGenAI } from '@google/genai';

const MODEL_CHAIN = (
  process.env.GEMINI_MODEL
    ? [process.env.GEMINI_MODEL]
    : ['gemini-3.5-flash-lite', 'gemini-3.5-flash', 'gemini-3.1-flash-lite', 'gemini-3.6-flash']
).filter(Boolean);

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.end(JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

function stripFences(text) {
  let t = String(text || '').trim();
  return t.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
}

function extractJsonObject(text) {
  const cleaned = stripFences(text);
  try {
    return JSON.parse(cleaned);
  } catch {}
  const s = cleaned.indexOf('{');
  const e = cleaned.lastIndexOf('}');
  if (s >= 0 && e > s) {
    const slice = cleaned.slice(s, e + 1);
    try {
      return JSON.parse(slice);
    } catch {}
    try {
      return JSON.parse(slice.replace(/,\s*([}\]])/g, '$1'));
    } catch {}
  }
  throw new Error('Malformed AI output');
}

function isRetryable(msg) {
  return /503|UNAVAILABLE|high demand|overloaded|RESOURCE_EXHAUSTED|rate|429|quota|temporarily/i.test(String(msg || ''));
}

async function generateJSON(apiKey, prompt) {
  const ai = new GoogleGenAI({ apiKey });
  let lastErr = null;
  for (const model of MODEL_CHAIN) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: { temperature: 0.55, maxOutputTokens: 512, responseMimeType: 'application/json' },
      });
      const text = response && response.text ? String(response.text) : '';
      if (!text.trim()) {
        lastErr = new Error('Empty response');
        continue;
      }
      return extractJsonObject(text);
    } catch (err) {
      lastErr = err;
      const msg = String(err?.message || err || '');
      if (/API_KEY|401|403/i.test(msg)) break;
      if (!isRetryable(msg) && MODEL_CHAIN.length === 1) break;
    }
  }
  throw lastErr || new Error('All models failed');
}

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') return json(res, 204, {});
  if (req.method !== 'POST') return json(res, 405, { error: 'Method not allowed' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return json(res, 500, { error: 'Missing GEMINI_API_KEY' });

  let body;
  try {
    body = typeof req.body === 'object' && req.body ? req.body : await readBody(req);
  } catch {
    return json(res, 400, { error: 'Invalid JSON' });
  }

  const title = String(body.title || '').slice(0, 200);
  const text = String(body.text || body.transcript || '').slice(0, 4000);
  const type = String(body.type || 'Normal').slice(0, 40);
  const vividness = body.vividness != null ? body.vividness : 5;
  if (!text.trim()) return json(res, 400, { error: 'No dream text' });

  const prompt = `You interpret one dream for a private journal.
Find the single most meaningful insight this dream offers.
Return ONLY valid JSON (no markdown, no extra text):
{
  "reading": "One or two short sentences starting with: This dream is suggesting that...",
  "questions": ["question 1", "question 2", "question 3"]
}

Rules:
- reading must start with exactly: This dream is suggesting that
- Keep reading under 45 words. Capture the most meaningful core of THIS dream. Clear, no fluff.
- Exactly 3 reasonably generalised reflective questions that still clearly relate to details or feelings from this dream.
- No medical diagnosis. No long essays. No symbol lists.
- Stay faithful to the dream text. Do not invent details.

Type: ${type}
Vividness: ${vividness}/10
Title: ${title || '(untitled)'}
Transcript:
${text}`;

  try {
    const parsed = await generateJSON(apiKey, prompt);
    let reading = String(parsed.reading || '').trim().slice(0, 400);
    if (reading && !/^this dream is suggesting that/i.test(reading)) {
      reading = 'This dream is suggesting that ' + reading.replace(/^that\s+/i, '');
    }
    let questions = Array.isArray(parsed.questions)
      ? parsed.questions.map((q) => String(q).slice(0, 140)).filter(Boolean).slice(0, 3)
      : [];
    while (questions.length < 3) questions.push('What part of this dream still feels unfinished?');
    return json(res, 200, { reading, questions: questions.slice(0, 3) });
  } catch (err) {
    const msg = String(err?.message || err || '');
    console.error('[meaning]', msg.slice(0, 200));
    if (isRetryable(msg)) return json(res, 503, { error: 'The model is busy right now. Wait a few seconds and try again.' });
    return json(res, 500, { error: 'Meaning request failed. Try again in a moment.' });
  }
}
