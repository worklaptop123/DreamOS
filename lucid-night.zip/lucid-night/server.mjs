import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = 3000;

try {
  const env = fs.readFileSync(path.join(__dirname, '.env.local'), 'utf8');
  for (const line of env.split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch {}

const MODEL = process.env.GEMINI_MODEL || 'gemini-3.6-flash';

function sendJson(res, status, obj) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(JSON.stringify(obj));
}

function sendFile(res, status, buf, type) {
  res.writeHead(status, {
    'Content-Type': type + '; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(buf);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

async function handleAnalyze(req, res) {
  if (req.method !== 'POST') return sendJson(res, 405, { error: 'Method not allowed' });
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return sendJson(res, 500, { error: 'Missing GEMINI_API_KEY in .env.local' });

  let body;
  try {
    body = await readBody(req);
  } catch {
    return sendJson(res, 400, { error: 'Invalid JSON body' });
  }

  if (!Array.isArray(body.entries)) {
    return sendJson(res, 400, { error: 'entries must be an array' });
  }

  const entries = body.entries
    .slice(-30)
    .map((e) => ({
      date: String(e?.date || '').slice(0, 40),
      title: String(e?.title || '').slice(0, 200),
      text: String(e?.text || e?.transcript || '').slice(0, 3000),
    }))
    .filter((e) => e.text.trim());

  if (!entries.length) {
    return sendJson(res, 400, { error: 'No journal text to analyze' });
  }

  const prompt = `You analyze private dream-journal entries for pattern cards in an app.
Return ONLY valid JSON with this exact shape:
{
  "insight": "2-3 sentence overview of patterns across the entries",
  "people": [{"name": "person or role", "count": 1}],
  "emotions": [{"name": "emotion", "count": 1}],
  "animals": [{"name": "animal", "count": 1}],
  "actions": [{"name": "action verb or short phrase", "count": 1}]
}
Rules:
- count is how often that item appears across the provided entries (integer >= 1).
- Only include items clearly supported by the text.
- Prefer common names / clear roles for people.
- Emotions should be plain words (fear, joy, confusion, calm, etc.).
- Actions should be short (running, falling, flying, searching, etc.).
- Do not diagnose mental health.
- Do not invent entries or symbols not present.
- Keep lists to the strongest items (max 8 each).
- insight must be careful reflective language ("may suggest", "appears often").
Entries:
${JSON.stringify(entries)}`;

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: MODEL,
      contents: prompt,
      config: {
        temperature: 0.3,
        maxOutputTokens: 2048,
        responseMimeType: 'application/json',
      },
    });
    let text = (response?.text || '')
      .trim()
      .replace(/^```(?:json)?\s*/i, '')
      .replace(/\s*```$/i, '')
      .trim();
    const start = text.indexOf('{');
    const end = text.lastIndexOf('}');
    if (start >= 0 && end > start) text = text.slice(start, end + 1);
    const parsed = JSON.parse(text);
    const norm = (arr) =>
      (Array.isArray(arr) ? arr : [])
        .map((x) => ({
          name: String(x?.name || x?.symbol || '').trim().slice(0, 80),
          count: Math.max(1, parseInt(x?.count, 10) || 1),
        }))
        .filter((x) => x.name)
        .slice(0, 8);
    return sendJson(res, 200, {
      insight: String(parsed.insight || parsed.summary || '').slice(0, 1200),
      people: norm(parsed.people),
      emotions: norm(parsed.emotions),
      animals: norm(parsed.animals),
      actions: norm(parsed.actions),
    });
  } catch (err) {
    console.error('[analyze]', String(err?.message || err).slice(0, 240));
    return sendJson(res, 500, { error: 'Analytics request failed' });
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || '/', `http://localhost:${PORT}`);
  if (url.pathname === '/api/analyze') return handleAnalyze(req, res);

  let filePath = path.join(__dirname, url.pathname === '/' ? 'index.html' : url.pathname);
  if (!filePath.startsWith(__dirname)) {
    return sendFile(res, 403, Buffer.from('Forbidden'), 'text/plain');
  }
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(__dirname, 'index.html');
  }
  const ext = path.extname(filePath);
  const types = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.svg': 'image/svg+xml',
    '.png': 'image/png',
    '.ico': 'image/x-icon',
  };
  try {
    sendFile(res, 200, fs.readFileSync(filePath), types[ext] || 'application/octet-stream');
  } catch {
    sendFile(res, 404, Buffer.from('Not found'), 'text/plain');
  }
});

server.listen(PORT, () => {
  console.log('Lucid Night: http://localhost:' + PORT);
  console.log('Model:', MODEL);
  console.log(process.env.GEMINI_API_KEY ? 'GEMINI_API_KEY loaded' : 'WARNING: no GEMINI_API_KEY');
});
