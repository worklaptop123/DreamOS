/**
 * Lucid Night — local server
 * Serves index.html + POST /api/meaning + /api/analyze + /api/plan + /api/chat
 * Multi-model fallback when a model is overloaded (503).
 */
import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const MAX_BODY_BYTES = 1_000_000;

function loadEnvFile(name) {
  try {
    const raw = fs.readFileSync(path.join(__dirname, name), 'utf8');
    for (const line of raw.split('\n')) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (m && !process.env[m[1]]) {
        process.env[m[1]] = m[2].replace(/^["']|["']$/g, '').trim();
      }
    }
  } catch {}
}
loadEnvFile('.env.local');
loadEnvFile('.env');

// Prefer env override, then try these in order on 503 / overload
const MODEL_CHAIN = (
  process.env.GEMINI_MODEL
    ? [process.env.GEMINI_MODEL]
    : [
        // 3.6-flash often returns non-JSON / truncated payloads → keep as later fallback
        'gemini-3.5-flash-lite',
        'gemini-3.5-flash',
        'gemini-3.1-flash-lite',
        'gemini-3.6-flash',
      ]
).filter(Boolean);

function sendJson(res, status, obj) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(JSON.stringify(obj));
}

function sendFile(res, status, buf, type) {
  res.writeHead(status, {
    'Content-Type':
      type +
      (type.startsWith('text/') || type.includes('json') || type.includes('javascript')
        ? '; charset=utf-8'
        : ''),
    'Cache-Control': 'no-store',
  });
  res.end(buf);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;
    req.on('data', (c) => {
      total += c.length;
      if (total > MAX_BODY_BYTES) {
        reject(new Error('Body too large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

function stripFences(text) {
  let t = String(text || '').trim();
  return t.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
}

function extractJsonObject(text) {
  let cleaned = stripFences(text);
  // Some models prepend chatter or BOM
  cleaned = cleaned.replace(/^\uFEFF/, '').trim();
  const attempts = [];
  attempts.push(cleaned);
  const s = cleaned.indexOf('{');
  const e = cleaned.lastIndexOf('}');
  if (s >= 0 && e > s) attempts.push(cleaned.slice(s, e + 1));
  // Also try array root if object missing
  const as = cleaned.indexOf('[');
  const ae = cleaned.lastIndexOf(']');
  if (as >= 0 && ae > as && (s < 0 || as < s)) attempts.push(cleaned.slice(as, ae + 1));

  for (let slice of attempts) {
    if (!slice) continue;
    const variants = [
      slice,
      slice.replace(/,\s*([}\]])/g, '$1'),
      slice.replace(/[\u0000-\u001F]+/g, ' '),
      slice.replace(/,\s*([}\]])/g, '$1').replace(/[\u0000-\u001F]+/g, ' '),
      // smart quotes → plain
      slice.replace(/[\u201C\u201D]/g, '"').replace(/[\u2018\u2019]/g, "'"),
      // unescaped newlines inside strings (best-effort)
      slice.replace(/\r\n/g, '\\n').replace(/\n/g, '\\n').replace(/\r/g, '\\n'),
    ];
    for (const v of variants) {
      try { return JSON.parse(v); } catch {}
    }
  }
  throw new Error('Malformed AI output');
}

function isRetryable(msg) {
  return /503|UNAVAILABLE|high demand|overloaded|RESOURCE_EXHAUSTED|rate|429|quota|temporarily/i.test(
    String(msg || '')
  );
}

function isKeyError(msg) {
  return /API_KEY|INVALID_ARGUMENT|403|401|permission|invalid.*key/i.test(String(msg || ''));
}


function extractResponseText(response) {
  if (!response) return '';
  if (typeof response.text === 'string' && response.text.trim()) return response.text;
  if (typeof response.text === 'function') {
    try {
      const t = response.text();
      if (t) return String(t);
    } catch {}
  }
  try {
    const parts = response?.candidates?.[0]?.content?.parts;
    if (Array.isArray(parts)) {
      return parts.map((p) => (p && p.text) || '').join('');
    }
  } catch {}
  return '';
}

/**
 * Try each model in MODEL_CHAIN until one succeeds.
 */
async function generateJSON(apiKey, prompt, { temperature, maxOutputTokens }) {
  const ai = new GoogleGenAI({ apiKey });
  let lastErr = null;

  for (let i = 0; i < MODEL_CHAIN.length; i++) {
    const model = MODEL_CHAIN[i];
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          temperature,
          maxOutputTokens,
          responseMimeType: 'application/json',
        },
      });
      const text = extractResponseText(response);
      if (!text.trim()) {
        lastErr = new Error('Empty response from ' + model);
        console.error('[ai]', model, '→ empty');
        continue;
      }
      let parsed;
      try {
        parsed = extractJsonObject(text);
      } catch (parseErr) {
        lastErr = parseErr;
        console.error('[ai]', model, '→ Malformed AI output');
        continue;
      }
      if (i > 0) console.log('[ai] fallback ok →', model);
      return { parsed, model, raw: text };
    } catch (err) {
      const msg = String(err?.message || err || '');
      console.error('[ai]', model, '→', msg.slice(0, 180));
      lastErr = err;
      if (isKeyError(msg)) break; // key problem — don't burn through models
      // skip permanently dead / not-found models immediately
      if (/404|NOT_FOUND|no longer available/i.test(msg)) continue;
      if (isRetryable(msg)) {
        // brief pause before next model when rate-limited
        await new Promise(r => setTimeout(r, 600));
      }
    }
  }
  throw lastErr || new Error('All models failed');
}

/* ─── /api/meaning ───────────────────────────────────────────────────────── */

async function handleMeaning(req, res) {
  if (req.method === 'OPTIONS') return sendJson(res, 204, {});
  if (req.method !== 'POST') return sendJson(res, 405, { error: 'Method not allowed' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return sendJson(res, 500, {
      error: 'Missing GEMINI_API_KEY. Create .env.local with your key and restart.',
    });
  }

  let body;
  try {
    body = await readBody(req);
  } catch (err) {
    if (/too large/i.test(String(err?.message))) return sendJson(res, 413, { error: 'Request body too large' });
    return sendJson(res, 400, { error: 'Invalid JSON body' });
  }

  const title = String(body.title || '').slice(0, 200);
  const text = String(body.text || body.transcript || '').slice(0, 4000);
  const type = String(body.type || 'Normal').slice(0, 40);
  const vividness = body.vividness != null ? body.vividness : 5;

  if (!text.trim()) return sendJson(res, 400, { error: 'No dream text' });

  const prompt = `You are interpreting one private dream journal entry.
Find the single most meaningful insight this dream offers the dreamer.
Reply with ONLY a single JSON object. No markdown. No code fences. No extra keys.

Required shape:
{"reading":"This dream is suggesting that ...","questions":["...","...","..."]}

Hard rules:
1. "reading" MUST start with exactly: This dream is suggesting that
2. "reading" is 1-2 sentences, 20-45 words. It must capture the most meaningful core of THIS dream (specific people, places, actions, feelings present in the text). Avoid vague filler such as "a natural process" or "something in your life".
3. "questions" MUST be an array of exactly 3 strings.
4. Each question is reasonably generalised (so it still feels open and reflective) yet clearly related to details or feelings from THIS dream. Keep them short and distinct.
5. No medical or psychological diagnosis. No symbol dictionaries. Do not invent events not in the transcript.

Dream type: ${type}
Vividness: ${vividness}/10
Title: ${title || '(untitled)'}
Transcript:
${text}`;

  try {
    const { parsed } = await generateJSON(apiKey, prompt, {
      temperature: 0.65,
      maxOutputTokens: 768,
    });

    let reading = String(parsed.reading || '').trim().slice(0, 400);
    if (reading && !/^this dream is suggesting that/i.test(reading)) {
      reading = 'This dream is suggesting that ' + reading.replace(/^that\s+/i, '');
    }
    let questions = Array.isArray(parsed.questions)
      ? parsed.questions.map((q) => String(q).trim().slice(0, 160)).filter(Boolean)
      : [];
    // de-dupe while preserving order
    const seen = new Set();
    questions = questions.filter((q) => {
      const k = q.toLowerCase();
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    }).slice(0, 3);

    // Only pad with distinct, neutral prompts if the model returned fewer than 3
    const fillers = [
      'Which image from this dream still feels unfinished?',
      'What feeling in this dream was strongest for you?',
      'If one detail could change, which would it be?',
    ];
    for (const f of fillers) {
      if (questions.length >= 3) break;
      if (!seen.has(f.toLowerCase())) questions.push(f);
    }

    if (!reading || reading.length < 40) {
      return sendJson(res, 502, { error: 'Meaning was too thin — open the dream again to retry.' });
    }

    return sendJson(res, 200, { reading, questions: questions.slice(0, 3) });
  } catch (err) {
    const msg = String(err?.message || err || '').slice(0, 300);
    console.error('[meaning]', msg);
    if (isRetryable(msg)) {
      return sendJson(res, 503, {
        error: 'The model is busy right now. Wait a few seconds and try again.',
      });
    }
    if (isKeyError(msg)) {
      return sendJson(res, 500, { error: 'Invalid or missing API key. Check GEMINI_API_KEY in .env.local' });
    }
    return sendJson(res, 500, { error: 'Meaning request failed. Try again in a moment.' });
  }
}

/* ─── /api/analyze ───────────────────────────────────────────────────────── */

const MAX_ENTRIES = 30;
const MAX_TITLE = 200;
const MAX_TEXT = 3000;

function sanitizeEntries(entries) {
  if (!Array.isArray(entries)) return null;
  return entries
    .slice(-MAX_ENTRIES)
    .map((entry) => ({
      date: entry && entry.date ? String(entry.date).slice(0, 40) : '',
      title: String((entry && entry.title) || '').slice(0, MAX_TITLE),
      text: String((entry && (entry.text || entry.transcript)) || '').slice(0, MAX_TEXT),
    }))
    .filter((e) => e.text.trim().length > 0);
}

function namedCounts(arr, nameKey, max) {
  if (!Array.isArray(arr)) return [];
  const out = [];
  const seen = new Set();
  for (const item of arr) {
    if (out.length >= max) break;
    let name = '';
    let count = 1;
    if (typeof item === 'string') name = item;
    else if (item && typeof item === 'object') {
      name = String(item[nameKey] || item.name || item.label || '').trim();
      count = Math.max(1, Number(item.count != null ? item.count : 1) || 1);
    }
    name = name.slice(0, 80);
    if (!name) continue;
    const k = name.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push({ name, count });
  }
  return out;
}

function normalizeAnalytics(parsed) {
  const emotionsRaw = Array.isArray(parsed.emotions) ? parsed.emotions : [];
  const emotions = [];
  const seenE = new Set();
  for (const e of emotionsRaw) {
    if (emotions.length >= 12) break;
    let name = '';
    let strength = 5;
    let count = 1;
    if (typeof e === 'string') name = e;
    else if (e && typeof e === 'object') {
      name = String(e.emotion || e.name || '').trim();
      strength = Math.min(10, Math.max(0, Number(e.strength != null ? e.strength : 5) || 5));
      count = Math.max(1, Number(e.count != null ? e.count : 1) || 1);
    }
    name = name.slice(0, 60);
    if (!name) continue;
    const k = name.toLowerCase();
    if (seenE.has(k)) continue;
    seenE.add(k);
    emotions.push({ name, count, strength });
  }

  return {
    summary: String(parsed.summary || '').slice(0, 2000),
    dreamOverview: String(parsed.dreamOverview || parsed.overview || '').slice(0, 1200),
    themes: Array.isArray(parsed.themes)
      ? parsed.themes.slice(0, 12).map((t) => String(t).slice(0, 80)).filter(Boolean)
      : [],
    people: namedCounts(parsed.people, 'name', 12),
    places: namedCounts(parsed.places, 'name', 12),
    animals: namedCounts(parsed.animals, 'name', 12),
    actions: namedCounts(parsed.actions, 'name', 12),
    presences: namedCounts(parsed.presences, 'name', 12),
    emotions,
    recurringSymbols: Array.isArray(parsed.recurringSymbols)
      ? parsed.recurringSymbols.slice(0, 12).map((s) => ({
          symbol: String((s && s.symbol) || s || '').slice(0, 80),
          count: Math.max(0, Number((s && s.count) != null ? s.count : 1) || 1),
          possibleMeaning: String((s && s.possibleMeaning) || '').slice(0, 200),
        })).filter((s) => s.symbol)
      : [],
    reflectionQuestions: Array.isArray(parsed.reflectionQuestions)
      ? parsed.reflectionQuestions.slice(0, 8).map((q) => String(q).slice(0, 300)).filter(Boolean)
      : [],
    disclaimer:
      String(parsed.disclaimer || '').trim() ||
      'This is reflective pattern analysis, not medical or psychological diagnosis.',
  };
}

function buildAnalyzePrompt(limitedEntries, extra = {}) {
  const mostRecent = extra.mostRecent || (limitedEntries[0] || null);
  const dreamTypes = extra.dreamTypes || {};
  const hints = extra.hints || {};

  return `You analyse private dream journal entries. Focus especially on the MOST RECENT dream while still noticing patterns across the set. You are the ONLY source of people, places, animals, actions, emotions, and presences lists that will appear in the analytics UI.

Return ONLY one JSON object. No markdown. No code fences.

Shape:
{
  "summary": "2-4 sentences on concrete patterns, prioritising the most recent dream",
  "dreamOverview": "2-4 short sentences: a generalized, gentle interpretation connecting common dream themes in these entries to possible real-life emotions or situations. Use words like may, could, can sometimes, might. Never present interpretations as facts or diagnoses.",
  "themes": ["theme1", "theme2"],
  "people": [{ "name": "Proper name or clear role only", "count": 1 }],
  "places": [{ "name": "Specific place", "count": 1 }],
  "animals": [{ "name": "Animal", "count": 1 }],
  "actions": [{ "name": "Meaningful action", "count": 1 }],
  "presences": [{ "name": "Ghost / shadow / presence label", "count": 1 }],
  "emotions": [{ "emotion": "feeling", "strength": 7, "count": 1 }],
  "recurringSymbols": [{ "symbol": "symbol", "count": 2, "possibleMeaning": "may suggest ..." }],
  "reflectionQuestions": ["q1", "q2", "q3"],
  "disclaimer": "This is reflective pattern analysis, not medical or psychological diagnosis."
}

Hard rules for people / places / animals / actions / emotions / presences:
- ONLY real proper names, clear roles (mom, teacher), real places, real animals, meaningful verbs, clear feelings, and presence-like beings from the text.
- presences = ghosts, spirits, shadows, dark figures, weird unseen feelings of being watched, entities, phantoms, demons, angels, aliens, creatures felt as a presence (not ordinary animals or people already listed).
- NEVER output grammar fragments: "was there", "i was", "there", "someone", "something", "it", "they".
- NEVER invent names or details not present in the entries.
- count = how many entries that item appears in (minimum 1).
- If none, use [].
- Give extra weight to the most recent dream when ranking and counting.

dreamOverview rules:
- Short and easy to read (2-4 sentences).
- Connect themes that appear (e.g. water, chasing, falling, flying, monsters, being trapped) to possible waking-life feelings using tentative language only.
- Examples of tone: nightmares may relate to stress; being chased might relate to pressure; falling can sometimes reflect uncertainty; water may relate to emotions; flying might connect with freedom or wanting more control; death in dreams is usually symbolic of change or endings, not literal.
- Never diagnose, predict harm, or claim certainty.

Other rules:
- themes: 3-6 short phrases from the dreams
- emotions: 2-6 items, strength 1-10
- reflectionQuestions: exactly 3, different, tied to the dreams (especially the latest)
- No medical diagnosis

Dream type counts across the journal: ${JSON.stringify(dreamTypes)}
Most recent dream: ${JSON.stringify(mostRecent)}
Optional local hints (may be incomplete — verify against the text): ${JSON.stringify(hints)}

All entries (most recent first):
${JSON.stringify(limitedEntries)}`;
}

async function handleAnalyze(req, res) {
  if (req.method === 'OPTIONS') return sendJson(res, 204, {});
  if (req.method !== 'POST') return sendJson(res, 405, { error: 'Method not allowed' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return sendJson(res, 500, {
      error: 'Missing GEMINI_API_KEY. Create .env.local with your key and restart.',
    });
  }

  let body;
  try {
    body = await readBody(req);
  } catch (err) {
    if (/too large/i.test(String(err?.message))) return sendJson(res, 413, { error: 'Request body too large' });
    return sendJson(res, 400, { error: 'Invalid JSON body' });
  }

  const limitedEntries = sanitizeEntries(body.entries);
  if (!limitedEntries) return sendJson(res, 400, { error: 'entries must be an array' });
  if (!limitedEntries.length) return sendJson(res, 400, { error: 'No journal text to analyze' });

  const extra = {
    mostRecent: body.mostRecent || limitedEntries[0] || null,
    dreamTypes: body.dreamTypes || {},
    hints: body.hints || {},
  };

  try {
    const { parsed } = await generateJSON(apiKey, buildAnalyzePrompt(limitedEntries, extra), {
      temperature: 0.4,
      maxOutputTokens: 2048,
    });
    return sendJson(res, 200, normalizeAnalytics(parsed));
  } catch (error) {
    const msg = String((error && error.message) || error || '').slice(0, 300);
    console.error('[analyze]', msg);
    if (isRetryable(msg)) {
      return sendJson(res, 503, {
        error: 'The model is busy right now. Wait a few seconds and try again.',
      });
    }
    if (isKeyError(msg)) {
      return sendJson(res, 500, { error: 'Invalid or missing API key. Check GEMINI_API_KEY in .env.local' });
    }
    return sendJson(res, 500, { error: 'Analytics request failed. Try again in a moment.' });
  }
}

/* ─── /api/plan ──────────────────────────────────────────────────────────── */

function buildPlanPrompt(entries, existing, instruction) {
  return `You create a fun, practical, age-safe personal lucid dreaming PLAN from a private dream journal.

Return ONLY one JSON object. No markdown.

Shape:
{
  "title": "short punchy plan name",
  "tagline": "one exciting sentence",
  "level": "Spark | Explorer | Navigator | Dream Rider",
  "xpTarget": 100,
  "focus": "main skill this week",
  "mission": "2-3 sentences: why THIS journal points to this plan. Mention real dream signs from the entries.",
  "dreamSigns": ["sign from the journal", "another"],
  "goals": [
    { "id": "g1", "title": "short goal", "why": "why it helps lucidity", "xp": 15 }
  ],
  "days": [
    { "id": "d1", "name": "Mon", "title": "short day title", "tasks": ["tiny action 1", "tiny action 2"], "tip": "one line tip" }
  ],
  "quests": [
    { "id": "q1", "name": "quest name", "desc": "what to try in a dream or by day", "stars": 2 }
  ],
  "realityCue": "one custom reality-check tied to their dream signs",
  "bedtimeScript": "4-6 short lines they can whisper as they fall asleep. Gentle, no fear.",
  "coachNote": "one encouraging closer"
}

Rules:
- Family-friendly. No horror, no substances, no sleep deprivation, no mid-night alarm bootcamps, no medical claims.
- Techniques allowed: dream journal, reality checks, gentle MILD intention, spotting personal dream signs, consistent sleep, morning recall, calm visualization.
- Use the actual people/places/themes/animals from the journal as dream signs when present.
- Exactly 5 goals, 7 days (Mon-Sun), 3 quests.
- Keep language energetic, game-like, clear.
- If an existing plan + instruction is provided, REWRITE the plan to apply that instruction while keeping useful parts.
${instruction ? 'Rewrite instruction from the dreamer: ' + instruction : 'Create a fresh plan.'}
Existing plan (may be null): ${JSON.stringify(existing).slice(0, 3500)}
Journal entries (most recent first): ${JSON.stringify(entries).slice(0, 9000)}`;
}

function normalizePlan(parsed) {
  const goalsIn = Array.isArray(parsed.goals) ? parsed.goals : [];
  const daysIn = Array.isArray(parsed.days) ? parsed.days : [];
  const questsIn = Array.isArray(parsed.quests) ? parsed.quests : [];
  const signs = Array.isArray(parsed.dreamSigns) ? parsed.dreamSigns : [];
  const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const goals = [];
  for (let i = 0; i < 5; i++) {
    const g = goalsIn[i] || {};
    goals.push({
      id: String(g.id || 'g' + (i + 1)).slice(0, 24),
      title: String(g.title || 'Practice a reality check today').slice(0, 80),
      why: String(g.why || 'Builds the habit of noticing you are dreaming.').slice(0, 160),
      xp: Math.min(40, Math.max(10, Number(g.xp) || 15)),
    });
  }
  const days = dayNames.map((name, i) => {
    const d = daysIn[i] || {};
    const tasks = Array.isArray(d.tasks) ? d.tasks.map((t) => String(t).slice(0, 90)).filter(Boolean).slice(0, 3) : [];
    if (!tasks.length) tasks.push('Write any dream fragment you remember');
    return {
      id: String(d.id || 'd' + (i + 1)).slice(0, 24),
      name,
      title: String(d.title || name + ' practice').slice(0, 60),
      tasks,
      tip: String(d.tip || 'Stay curious, not forceful.').slice(0, 140),
    };
  });
  const quests = [];
  for (let i = 0; i < 3; i++) {
    const q = questsIn[i] || {};
    quests.push({
      id: String(q.id || 'q' + (i + 1)).slice(0, 24),
      name: String(q.name || 'Dream sign hunt').slice(0, 60),
      desc: String(q.desc || 'Spot one repeating detail from your journal.').slice(0, 180),
      stars: Math.min(3, Math.max(1, Number(q.stars) || 2)),
    });
  }
  return {
    title: String(parsed.title || 'Night Path').slice(0, 60),
    tagline: String(parsed.tagline || 'A custom path toward noticing you are dreaming.').slice(0, 160),
    level: String(parsed.level || 'Explorer').slice(0, 32),
    xpTarget: Math.min(200, Math.max(50, Number(parsed.xpTarget) || 100)),
    focus: String(parsed.focus || 'Dream recall + reality checks').slice(0, 80),
    mission: String(parsed.mission || 'Use your journal as a map of repeating dream signs.').slice(0, 500),
    dreamSigns: signs.map((s) => String(s).slice(0, 40)).filter(Boolean).slice(0, 8),
    goals,
    days,
    quests,
    realityCue: String(parsed.realityCue || 'When you see a doorway, ask: am I dreaming?').slice(0, 200),
    bedtimeScript: String(parsed.bedtimeScript || 'Tonight I notice my dreams.\nWhen I dream, I will know I am dreaming.').slice(0, 500),
    coachNote: String(parsed.coachNote || 'Log every fragment. Recall is the unlock key.').slice(0, 240),
  };
}

async function handlePlan(req, res) {
  if (req.method === 'OPTIONS') return sendJson(res, 204, {});
  if (req.method !== 'POST') return sendJson(res, 405, { error: 'Method not allowed' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return sendJson(res, 500, { error: 'Missing GEMINI_API_KEY. Create .env.local with your key and restart.' });
  }

  let body;
  try {
    body = await readBody(req);
  } catch (err) {
    if (/too large/i.test(String(err?.message))) return sendJson(res, 413, { error: 'Request body too large' });
    return sendJson(res, 400, { error: 'Invalid JSON body' });
  }

  const entries = Array.isArray(body.entries) ? body.entries.slice(-20).map((e) => ({
    date: String((e && (e.date || e.createdAt)) || '').slice(0, 40),
    title: String((e && e.title) || '').slice(0, 200),
    text: String((e && (e.text || e.transcript)) || '').slice(0, 1800),
    type: String((e && e.type) || '').slice(0, 40),
  })).filter((e) => e.text.trim()) : [];

  if (entries.length < 1) return sendJson(res, 400, { error: 'Need journal entries to build a plan.' });

  const existing = body.existingPlan && typeof body.existingPlan === 'object' ? body.existingPlan : null;
  const instruction = String(body.instruction || '').slice(0, 800);

  try {
    const { parsed } = await generateJSON(apiKey, buildPlanPrompt(entries, existing, instruction), {
      temperature: 0.7,
      maxOutputTokens: 2500,
    });
    return sendJson(res, 200, normalizePlan(parsed));
  } catch (err) {
    const msg = String(err?.message || err || '').slice(0, 300);
    console.error('[plan]', msg);
    if (isRetryable(msg)) return sendJson(res, 503, { error: 'The model is busy right now. Wait a few seconds and try again.' });
    if (isKeyError(msg)) return sendJson(res, 500, { error: 'Invalid or missing API key. Check GEMINI_API_KEY in .env.local' });
    return sendJson(res, 500, { error: 'Plan request failed. Try again in a moment.' });
  }
}

/* ─── /api/chat ──────────────────────────────────────────────────────────── */

async function handleChat(req, res) {
  if (req.method === 'OPTIONS') return sendJson(res, 204, {});
  if (req.method !== 'POST') return sendJson(res, 405, { error: 'Method not allowed' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return sendJson(res, 500, { error: 'Missing GEMINI_API_KEY. Create .env.local with your key and restart.' });
  }

  let body;
  try {
    body = await readBody(req);
  } catch (err) {
    if (/too large/i.test(String(err?.message))) return sendJson(res, 413, { error: 'Request body too large' });
    return sendJson(res, 400, { error: 'Invalid JSON body' });
  }

  const message = String(body.message || '').slice(0, 1200);
  if (!message.trim()) return sendJson(res, 400, { error: 'Empty message' });

  const history = Array.isArray(body.history)
    ? body.history.slice(-12).map((m) => ({
        role: m && m.role === 'guide' ? 'guide' : 'you',
        text: String((m && m.text) || '').slice(0, 800),
      }))
    : [];
  const entries = Array.isArray(body.entries) ? body.entries.slice(-24).map((e) => ({
    date: String((e && (e.date || e.createdAt)) || '').slice(0, 40),
    title: String((e && e.title) || '').slice(0, 120),
    text: String((e && (e.text || e.transcript)) || '').slice(0, 1200),
    type: String((e && e.type) || '').slice(0, 40),
  })) : [];

  const prompt = `You are Lucid Genius, a helpful dream chat. Sound like a normal person — clear, friendly, not cutesy.
No "heyyy", "oooh", "dream muscle", or hype-coach talk.

Rules:
- Stay on dreams, sleep, and lucid dreaming.
- You can ONLY use attached dreams below. If the list is empty, you do not know their journal. Tell them to attach a dream with the clip button if they want you to read one.
- Never invent journal details that are not in the attached list.
- Greetings get a normal hello plus a simple dream invite. Not just "hey".
- Short messages can get short replies. Real questions get a useful answer.
- Break up text. Use bullets when a list helps.
- Family-friendly. No medical diagnosis.

Return ONLY JSON: {"reply":"text"}

Attached dreams (only these): ${JSON.stringify(entries).slice(0, 12000)}
Chat history: ${JSON.stringify(history).slice(0, 4000)}
User message: ${message}`;

  try {
    const { parsed } = await generateJSON(apiKey, prompt, {
      temperature: 0.75,
      maxOutputTokens: 1100,
    });
    const reply = String(parsed.reply || '').trim().slice(0, 1800)
      || 'Ask me anything about a dream in your journal.';
    return sendJson(res, 200, { reply });
  } catch (err) {
    const msg = String(err?.message || err || '').slice(0, 300);
    console.error('[chat]', msg);
    if (isRetryable(msg)) return sendJson(res, 503, { error: 'The model is busy right now. Wait a few seconds and try again.' });
    if (isKeyError(msg)) return sendJson(res, 500, { error: 'Invalid or missing API key. Check GEMINI_API_KEY in .env.local' });
    return sendJson(res, 500, { error: 'Chat request failed. Try again in a moment.' });
  }
}

/* ─── static + router ────────────────────────────────────────────────────── */

const MIME = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.mjs': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', `http://localhost:${PORT}`);

    if (url.pathname === '/api/meaning') return handleMeaning(req, res);
    if (url.pathname === '/api/analyze') return handleAnalyze(req, res);
    if (url.pathname === '/api/plan') return handlePlan(req, res);
    if (url.pathname === '/api/chat') return handleChat(req, res);

    let filePath = path.join(__dirname, url.pathname === '/' ? 'index.html' : url.pathname);
    const resolved = path.resolve(filePath);
    const root = path.resolve(__dirname);
    if (!resolved.startsWith(root + path.sep) && resolved !== root) {
      return sendFile(res, 403, Buffer.from('Forbidden'), 'text/plain');
    }
    filePath = resolved;
    if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
      filePath = path.join(__dirname, 'index.html');
    }
    const ext = path.extname(filePath).toLowerCase();
    const type = MIME[ext] || 'application/octet-stream';
    sendFile(res, 200, fs.readFileSync(filePath), type);
  } catch (err) {
    console.error('[server]', err);
    sendJson(res, 500, { error: 'Server error' });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('  Lucid Night → http://localhost:' + PORT);
  console.log('  Models: ' + MODEL_CHAIN.join(' → '));
  if (process.env.GEMINI_API_KEY) {
    console.log('  GEMINI_API_KEY: loaded ✓');
  } else {
    console.log('  WARNING: no GEMINI_API_KEY found');
    console.log('  → Create .env.local with: GEMINI_API_KEY=your_key');
    console.log('  → Then restart this server');
  }
  console.log('  Endpoints: /api/meaning  ·  /api/analyze  ·  /api/chat');
  console.log('  Bound to 127.0.0.1 only');
  console.log('');
});
