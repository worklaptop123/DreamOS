# Lucid Night — Dream journal with optional Gemini AI

Private on-device dream journal. All your dreams stay in the browser (`localStorage`).  
AI features are **optional** and only run when you ask:

- **Dream meaning** — open a dream card → short reading + 3 questions  
- **AI analytics** — Analytics page → people, places, animals, emotions, actions  
- **Dream Overview** — short, generalized connections between dream themes and possible waking-life feelings (tentative wording only; not a diagnosis)
- **Night Plan** — locked until you save 10 journal dreams, then Gemini builds a personal lucid plan (goals, week map, quests)
- **Night Guide chat** — dream-only chatbot that can rewrite the plan live

---

## Quick start (Mac)

### Requirements
- **Node.js 18 or newer** — check with `node -v`  
  If you don’t have it: https://nodejs.org

### 1. Unzip (from Downloads)

In Terminal:

```bash
cd ~/Downloads
unzip -o lucid-night-fixed-v13.zip
cd lucid-night
```

If the zip is somewhere else, drag the zip into Terminal after `cd ` to paste the path, or:

```bash
cd ~/Desktop
# or wherever you saved the zip
unzip -o lucid-night-fixed-v13.zip
cd lucid-night
```

### 2. Install dependencies

```bash
npm install
```

### 3. Create & open the env file (automatic)

```bash
npm run setup
```

This creates `.env.local` and **opens it in your text editor**.  
Paste your Gemini key like this:

```
GEMINI_API_KEY=your_actual_key_goes_here
```

Get a free key: https://aistudio.google.com/apikey  
(use a parent/guardian account if required)

**Save the file**, then close the editor.

### 4. Run the app

```bash
npm start
```

You should see:

```
  Lucid Night running at  http://localhost:3000
  Models: gemini-3.6-flash → 3.6 → 3.5 → 2.5-flash
  GEMINI_API_KEY: loaded ✓
  Endpoints: /api/meaning  ·  /api/analyze  ·  /api/plan  ·  /api/chat
```

Open **http://localhost:3000** in your browser.

- Save a dream → expand the card for an AI meaning (spinner shows while generating; result is saved and never re-fetched until the dream text changes)
- Go to **Analytics** → lists (people, places, animals, emotions, actions) and **Dream Overview** generate from your journal (especially the most recent dreams) and stay until a dream is added, edited, or deleted
- Go to **Night Plan** after 10 saved dreams → generate a custom lucid plan, check goals, and chat with Night Guide (dreams / plan edits only)

### API key (required for AI)

AI calls need your own Gemini key. It is **never** hard-coded.

1. Get a free key: https://aistudio.google.com/apikey  
2. Run `npm run setup` (creates `.env.local` and opens it)  
3. Set: `GEMINI_API_KEY=your_actual_key_goes_here`  
4. Save, then `npm start`

Without a key the app still runs; only meaning / analytics / Dream Overview requests will fail until the key is set.

---

## Commands cheat sheet

| Command | What it does |
|---------|----------------|
| `npm install` | Install packages (once) |
| `npm run setup` | Create `.env.local` and open it |
| `npm run env` | Same as setup |
| `npm start` | Start the app at http://localhost:3000 |

---

## Why “Meaning unavailable” / AI errors appear

| Cause | Fix |
|-------|-----|
| Opened `index.html` as a file (`file://...`) | Always use `npm start` → http://localhost:3000 |
| Missing `GEMINI_API_KEY` | `npm run setup`, paste key, save, restart `npm start` |
| Zip not found | `cd ~/Downloads` first (or the folder where the zip is) |

---

## Privacy & safety

- Dreams stay on your device unless you open a dream card or click **Generate analysis**.
- API key never goes in the browser or into Git.
- AI output is reflective only — not medical advice.

---

## Optional: deploy to Vercel

```bash
npm install
npx vercel
```

Add `GEMINI_API_KEY` in the Vercel dashboard → Environment Variables, then redeploy.
