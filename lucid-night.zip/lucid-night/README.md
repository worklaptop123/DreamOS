# Lucid Night — Project folder (Gemini AI analytics)

Private on-device dream journal with **optional** AI reflection via Google Gemini.

**Architecture**

```
Browser (index.html)
  → only after consent + button click
  → POST /api/analyze  (your serverless function)
  → Gemini API (key stays on the server)
  → JSON reflection back to the Analytics page
```

- No API key in `index.html` or any client JS.
- Local analytics (people, places, types, etc.) still work offline.
- AI is optional and requires an explicit consent checkbox.

---

## Files

| Path | Purpose |
|------|---------|
| `index.html` | Full Lucid Night app (UI unchanged; AI panel added on Analytics only) |
| `api/analyze.js` | Vercel serverless endpoint → Gemini |
| `package.json` | Depends on `@google/genai` |
| `vercel.json` | Routing / cache headers |
| `.env.example` | Template for `GEMINI_API_KEY` |
| `.gitignore` | Ignores `.env`, `node_modules`, `.vercel` |

---

## 1. Get a Gemini API key

1. Open [Google AI Studio](https://aistudio.google.com/).
2. Sign in (use a parent/guardian account if required by age rules).
3. Create an API key.
4. Copy it somewhere private — **never** paste it into `index.html` or commit it to Git.

---

## 2. Local launch (recommended for testing)

### Requirements
- Node.js 18+
- [Vercel CLI](https://vercel.com/docs/cli): `npm i -g vercel`

### Steps

```bash
cd lucid-night
npm install
cp .env.example .env.local
```

Edit `.env.local` and set:

```
GEMINI_API_KEY=paste_your_key_here
```

Start the local server (serves `index.html` **and** `/api/analyze`):

```bash
npx vercel dev
```

Open the URL Vercel prints (usually `http://localhost:3000`).

1. Create / enter your Lucid Night account in the app.
2. Save a few dreams.
3. Open **Analytics**.
4. Scroll to **Optional AI reflection**.
5. Tick consent → **Generate AI reflection**.

---

## 3. Deploy to Vercel (production)

```bash
cd lucid-night
npm install
npx vercel
```

In the Vercel dashboard:

1. Project → **Settings** → **Environment Variables**
2. Add `GEMINI_API_KEY` = your key (Production + Preview)
3. Redeploy:

```bash
npx vercel --prod
```

Your live site will call `https://YOUR_PROJECT.vercel.app/api/analyze`.

---

## 4. Netlify alternative (optional)

1. Install Netlify CLI: `npm i -g netlify-cli`
2. Move/adapt the function:
   - Create `netlify/functions/analyze.mjs` with the same logic as `api/analyze.js`
   - Point the frontend endpoint to `/.netlify/functions/analyze`  
     (change `GeminiAnalytics.endpoint` in `index.html` if needed)
3. Set `GEMINI_API_KEY` in Netlify site env vars.
4. `netlify dev` locally or `netlify deploy --prod`.

---

## 5. Cloudflare Workers alternative (optional)

Use a Worker that reads `GEMINI_API_KEY` from secrets and mirrors the same POST contract. Point `GeminiAnalytics.endpoint` at the Worker URL.

---

## Privacy behavior

| Mode | What happens |
|------|----------------|
| Default | All journal data stays in `localStorage` on the device |
| AI reflection | User must check consent, then click the button; up to **30** recent entries are sent (title ≤200 chars, text ≤3000 chars) |
| Server logs | Endpoint does **not** log journal body text |

Disclaimer returned by the API: reflective pattern analysis only — **not** medical or psychological diagnosis.

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| `Missing GEMINI_API_KEY` | Set env var and restart `vercel dev` / redeploy |
| `Consent required` | Tick the checkbox |
| `429` / quota | Wait or check AI Studio usage limits |
| CORS / 404 on `/api/analyze` | Use `vercel dev` or a real deploy — opening raw `index.html` as a file cannot reach the API |
| Empty AI output | Ensure dreams have transcript text; check Network tab for the POST response |

---

## Security checklist

- [ ] `GEMINI_API_KEY` only in env / Vercel settings  
- [ ] Not in Git, not in `index.html`  
- [ ] Consent required before send  
- [ ] Entry length limits enforced server-side  
