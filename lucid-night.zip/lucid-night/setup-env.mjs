/**
 * Creates .env.local from the example (if missing) and opens it
 * so you can paste GEMINI_API_KEY.
 *
 * Usage:  npm run setup
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import os from 'os';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const example = path.join(__dirname, '.env.example');
const target = path.join(__dirname, '.env.local');

if (!fs.existsSync(example)) {
  console.error('Missing .env.example — re-download the project zip.');
  process.exit(1);
}

if (!fs.existsSync(target)) {
  fs.copyFileSync(example, target);
  console.log('Created .env.local from .env.example');
} else {
  console.log('.env.local already exists — opening it for you.');
}

console.log('');
console.log('  Paste your key on this line:');
console.log('  GEMINI_API_KEY=your_actual_key_goes_here');
console.log('');
console.log('  Get a free key: https://aistudio.google.com/apikey');
console.log('  Save the file, then run:  npm start');
console.log('');

const platform = os.platform();
let cmd;
let args;

if (platform === 'darwin') {
  // macOS — TextEdit (or default app for .local / plain text)
  cmd = 'open';
  args = ['-t', target]; // -t = open in default text editor
} else if (platform === 'win32') {
  cmd = 'cmd';
  args = ['/c', 'start', '', target];
} else {
  // Linux: prefer $EDITOR, then xdg-open, then nano
  const editor = process.env.EDITOR || process.env.VISUAL;
  if (editor) {
    cmd = editor;
    args = [target];
  } else {
    cmd = 'xdg-open';
    args = [target];
  }
}

const child = spawn(cmd, args, { stdio: 'ignore', detached: true, shell: platform === 'win32' });
child.on('error', () => {
  console.log('Could not open the editor automatically.');
  console.log('Open this file yourself:');
  console.log('  ' + target);
});
child.unref();
